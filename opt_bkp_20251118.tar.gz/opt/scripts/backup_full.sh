#!/bin/bash

################################################################################
# Script: backup_full.sh
# Descripción: Script de backup con compresión tar.gz
# Ubicación: /opt/scripts/backup_full.sh
################################################################################

# Colores para mensajes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Función de ayuda
mostrar_ayuda() {
    cat << EOF
${GREEN}=================================================================
SCRIPT DE BACKUP FULL - backup_full.sh
=================================================================${NC}

${YELLOW}USO:${NC}
    $0 -o <origen> -d <destino> [-h]

${YELLOW}OPCIONES:${NC}
    -o, --origen    Directorio o archivo de origen a backupear
    -d, --destino   Directorio destino donde se guardará el backup
    -h, --help      Muestra esta ayuda

${YELLOW}EJEMPLOS:${NC}
    $0 -o /var/log -d /backup_dir
    $0 --origen /www_dir --destino /backup_dir

${YELLOW}DESCRIPCIÓN:${NC}
    Este script realiza backups comprimidos en formato tar.gz
    Los archivos generados incluyen la fecha en formato AAAAMMDD
    
    Ejemplo de nombre generado:
    - Origen: /var/log
    - Resultado: log_bkp_20240302.tar.gz

${YELLOW}VALIDACIONES:${NC}
    ✓ Verifica que el directorio origen exista
    ✓ Verifica que el directorio destino exista y sea escribible
    ✓ Verifica que los sistemas de archivos estén montados
    ✓ Registra todas las operaciones en log

${YELLOW}UBICACIÓN DE LOGS:${NC}
    /var/log/backup_full.log

EOF
    exit 0
}

# Función para logging
log_mensaje() {
    local nivel=$1
    shift
    local mensaje="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local log_file="/var/log/backup_full.log"
    
    echo "[${timestamp}] [${nivel}] ${mensaje}" | tee -a "$log_file"
}

# Función para validar que un directorio existe
validar_directorio_existe() {
    local dir=$1
    if [ ! -d "$dir" ]; then
        log_mensaje "ERROR" "El directorio '$dir' no existe"
        return 1
    fi
    return 0
}

# Función para validar que el destino es escribible
validar_directorio_escribible() {
    local dir=$1
    if [ ! -w "$dir" ]; then
        log_mensaje "ERROR" "El directorio '$dir' no tiene permisos de escritura"
        return 1
    fi
    return 0
}

# Función para validar que el sistema de archivos está montado
validar_sistema_archivos_montado() {
    local dir=$1
    
    # Obtener el punto de montaje del directorio
    local mountpoint=$(df "$dir" 2>/dev/null | tail -1 | awk '{print $6}')
    
    if [ -z "$mountpoint" ]; then
        log_mensaje "ERROR" "No se pudo determinar el punto de montaje de '$dir'"
        return 1
    fi
    
    # Verificar que está en /proc/mounts
    if ! grep -q " $mountpoint " /proc/mounts 2>/dev/null; then
        log_mensaje "ERROR" "El sistema de archivos de '$dir' no está montado correctamente"
        return 1
    fi
    
    log_mensaje "INFO" "Sistema de archivos de '$dir' montado en: $mountpoint"
    return 0
}

# Función principal de backup
realizar_backup() {
    local origen=$1
    local destino=$2
    
    # Validaciones
    log_mensaje "INFO" "=== Iniciando proceso de backup ==="
    log_mensaje "INFO" "Origen: $origen"
    log_mensaje "INFO" "Destino: $destino"
    
    # Validar origen existe
    if ! validar_directorio_existe "$origen"; then
        exit 1
    fi
    
    # Validar destino existe
    if ! validar_directorio_existe "$destino"; then
        exit 1
    fi
    
    # Validar destino es escribible
    if ! validar_directorio_escribible "$destino"; then
        exit 1
    fi
    
    # Validar sistemas de archivos montados
    log_mensaje "INFO" "Validando sistemas de archivos..."
    if ! validar_sistema_archivos_montado "$origen"; then
        exit 1
    fi
    
    if ! validar_sistema_archivos_montado "$destino"; then
        exit 1
    fi
    
    # Generar nombre del archivo de backup
    local fecha=$(date +%Y%m%d)
    local nombre_base=$(basename "$origen")
    local archivo_backup="${nombre_base}_bkp_${fecha}.tar.gz"
    local ruta_completa="${destino}/${archivo_backup}"
    
    log_mensaje "INFO" "Nombre del backup: $archivo_backup"
    
    # Verificar espacio disponible
    local espacio_necesario=$(du -sb "$origen" | awk '{print $1}')
    local espacio_disponible=$(df -B1 "$destino" | tail -1 | awk '{print $4}')
    
    if [ "$espacio_necesario" -gt "$espacio_disponible" ]; then
        log_mensaje "ERROR" "Espacio insuficiente en destino"
        log_mensaje "ERROR" "Necesario: $(numfmt --to=iec $espacio_necesario), Disponible: $(numfmt --to=iec $espacio_disponible)"
        exit 1
    fi
    
    # Realizar backup
    log_mensaje "INFO" "Iniciando compresión..."
    if tar -czf "$ruta_completa" -C "$(dirname "$origen")" "$(basename "$origen")" 2>/dev/null; then
        local tamano=$(du -h "$ruta_completa" | awk '{print $1}')
        log_mensaje "SUCCESS" "Backup completado exitosamente"
        log_mensaje "SUCCESS" "Archivo: $ruta_completa"
        log_mensaje "SUCCESS" "Tamaño: $tamano"
        
        # Verificar integridad
        if tar -tzf "$ruta_completa" >/dev/null 2>&1; then
            log_mensaje "SUCCESS" "Integridad del archivo verificada"
        else
            log_mensaje "WARNING" "No se pudo verificar la integridad del archivo"
        fi
    else
        log_mensaje "ERROR" "Falló la creación del backup"
        exit 1
    fi
    
    log_mensaje "INFO" "=== Proceso de backup finalizado ==="
}

# Parsear argumentos
ORIGEN=""
DESTINO=""

while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help|-help)
            mostrar_ayuda
            ;;
        -o|--origen)
            ORIGEN="$2"
            shift 2
            ;;
        -d|--destino)
            DESTINO="$2"
            shift 2
            ;;
        *)
            echo -e "${RED}Error: Opción desconocida '$1'${NC}"
            echo "Use -h o --help para ver la ayuda"
            exit 1
            ;;
    esac
done

# Validar que se proporcionaron los argumentos necesarios
if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
    echo -e "${RED}Error: Faltan argumentos obligatorios${NC}"
    echo ""
    mostrar_ayuda
fi

# Ejecutar backup
realizar_backup "$ORIGEN" "$DESTINO"
